import { useContext } from "react"

export const Logout = () => {
    
    return (
        <div>
            Logout page
        </div>
    )
}