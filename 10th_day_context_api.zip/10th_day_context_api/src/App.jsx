import logo from './logo.svg';
import './App.css';
import { Button } from './components/Body/Button';
// import {Cart} from "./components/Navbar/Cart"
import { Navbar } from './components/Navbar/Navbar';

function App() {

  return (
    <div className="App">
      <Navbar/>
      {/* <Button/> */}
    </div>
  );
}

export default App;
