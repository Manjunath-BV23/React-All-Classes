import logo from './logo.svg';
import './App.css';
import {Items} from "./components/Items"
import {Total} from "./components/Total"

function App() {
  return (
    < div>
      <Items name = "Books" add_className = "addBook" rem_className = "remBook" total_className = "totalBooks" stack = {13}/>
      <Items name = "Pens" add_className = "addPen" rem_className = "remPen" total_className = "totalPens" stack = {10} />
      <Items name = "Notebooks" add_className = "addNotebook" rem_className = "remNotebook" total_className = "totalNotebooks" stack = {44} />
      <Items name = "InkPens" add_className = "addInkpen" rem_className = "remInkpen" total_className = "totalInkpens" stack = {78} />
      <Total/>
    </div>
    
  );
}

export default App;
