export function Total (){
    return <div className="total">
        {145}
    </div>
}