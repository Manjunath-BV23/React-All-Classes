import { useState } from "react"

export function Items(props) {
    const [counter, setCounter] = useState(props.stack)

    const handleChange = (value) => {
        setCounter(counter + value)
    }

    return <div className="items">
        <span>{props.name}:</span> <br/>
        <button className= {props.add_className} onClick = {() => handleChange(1)}>Add 1</button> <br/>
        <button className={props.rem_className} onClick = {() => {
            if (counter >= 1){
                handleChange(-1)
            }
        }}>Rem 1</button> <br/>
        <span className= {props.total_className}>{counter}</span>

    </div>
}